#python -c "import torch; print(torch.cuda.is_available())"

import os
import shutil
# Define your folders
pointcloud_folder = "../../data/sem8/"
labels_subfolder = "sem8_labels_training"
output_folder_train = "../../data/sem8_prepared/train"
output_folder_test = "../../data/sem8_prepared/test"

# Make sure the output folders exist
os.makedirs(output_folder_train, exist_ok=True)
os.makedirs(output_folder_test, exist_ok=True)

# List all point cloud files in the folder
pointcloud_files = [f for f in os.listdir(pointcloud_folder) if f.endswith('.txt')]

for pc_file in pointcloud_files:
    print(pc_file)
    # Construct the full path for point cloud and label files
    pc_file_path = os.path.join(pointcloud_folder, pc_file)
    label_file_path = os.path.join(pointcloud_folder, labels_subfolder,
                                    pc_file.replace('.txt', '.labels'))
    
    if not os.path.exists(label_file_path):
        # If the label file does not exist, copy the point cloud file to the "test" folder
        shutil.copy(pc_file_path, os.path.join(output_folder_test, pc_file))
    else:
        # Prepare the output file path in "train" folder
        output_file_path = os.path.join(output_folder_train, 
                                        pc_file.replace('_intensity_rgb.txt', '_rgb_label.txt'))
        
        with open(pc_file_path, 'r') as pc_f, open(label_file_path, 'r') as label_f, open(output_file_path, 'w') as out_f:
            # Read label file lines to match with points
            labels = label_f.readlines()
            
            # Iterate over each line/point in the point cloud file
            for index, line in enumerate(pc_f):
                xyz_intensity_rgb = line.strip().split()  # Split by space
                label = labels[index].strip()  # Get the corresponding label
                
                # Combine xyz, rgb, and label (assuming intensity is not needed and RGB values are last 3 in the list)
                if int(label)>0:
                    l=int(label)-1
                    combined_line = f"{' '.join(xyz_intensity_rgb[:3])} {' '.join(xyz_intensity_rgb[-3:])} {l}\n"
                    
                    # Write the combined line to the output file
                    out_f.write(combined_line)

print("Processing completed.")
