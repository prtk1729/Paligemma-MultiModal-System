# Commande to use:
```bash
conda create -n dl3d python=3.10
conda activate dl3d
conda install numpy matplotlib scipy
python -mpip install open3d
python -m pip install pylas
```

## for CPU
```bash
conda install pytorch torchvision torchaudio cpuonly -c pytorch
```

## DEBUG

if pip is not the right used
```
which pip

python -m pip install open3d
```